#!/bin/bash
cd backend
echo "Starting World Risk backend server on port 3000..."
PORT=3000 node src/server.js
